﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WindowsFormsApp21
{
    class Costi
    {
        int prezzo;

        public int Prezzo { get => prezzo; set => prezzo = value; }
    }
}
