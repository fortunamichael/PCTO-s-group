﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WindowsFormsApp21
{
    class Log
    {
        string username;
        string password;
        public static Log credenziali;

        public string Username { get => username; set => username = value; }
        public string Password { get => password; set => password = value; }

        public Log(string u, string p)
        {
            username = u;
            password = p;
        }
    }
}
