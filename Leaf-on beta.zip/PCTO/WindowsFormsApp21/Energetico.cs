﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp21
{
    public partial class Energetico : Form
    {
        public Energetico()
        {
            InitializeComponent();
        }
        int kw = 0;
        private void button1_Click(object sender, EventArgs e)
        {
            kw = 0;
            if (checkBox1.Checked == true)
                kw = kw + 290;
            if (checkBox2.Checked == true)
                kw = kw + 83;
            if (checkBox3.Checked == true && checkBox4.Checked == true)
                kw = kw + 150;
            if (checkBox3.Checked == true || checkBox4.Checked == true)
                kw = kw + 75;
            if (checkBox5.Checked == true && checkBox6.Checked == true)
                kw = kw + 140;
            if (checkBox5.Checked == true || checkBox6.Checked == true)
                kw = kw + 70;
            if (checkBox7.Checked == true && checkBox8.Checked == true)
                kw = kw + 120;
            if (checkBox7.Checked == true || checkBox8.Checked == true)
                kw = kw + 60;
            if (checkBox9.Checked == true && checkBox10.Checked == true)
                kw = kw + 60;
            if (checkBox10.Checked == true || checkBox9.Checked == true)
                kw = kw + 30;
            if (checkBox11.Checked == true)
                kw = kw + 20;
            if (checkBox12.Checked == true)
                kw = kw + 50;

            label1.Text = "Fabbisogno energetico mensile:" + kw + "kw";

        }

    }
}
