﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp21
{
    public partial class Idroelettrica : Form
    {
        public Idroelettrica()
        {
            InitializeComponent();
        }

        private void Idroelettrica_Load(object sender, EventArgs e)
        {
            
        }
        public decimal P;
        public decimal Q;
        public decimal H;
        public decimal N;
        public double G;

        private void button1_Click(object sender, EventArgs e)
        {
            Q = numericUpDown1.Value;
            H = numericUpDown2.Value;
            N = numericUpDown3.Value;
            G = 9.81;
            P = (Convert.ToDecimal(G) * Q * H * N) / 100;
            listView1.Items.Clear();
            listView1.Items.Add("Potenza Generata: " + P + "W");
        }
    }
}
