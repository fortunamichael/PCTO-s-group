﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp21
{
    public partial class GestioneCosti : Form
    {
        public GestioneCosti()
        {
            InitializeComponent();
            textBox1.ReadOnly = true;
            textBox2.ReadOnly = true;
            button2.Enabled = false;
            label3.Text = "utile netto: " + utileNetto + "€";
        }
        int utileNetto = int.MaxValue;
        List<string> codici = new List<string>();
        private void button1_Click(object sender, EventArgs e)
        {
            string path = AppDomain.CurrentDomain.BaseDirectory + "./../../../Gestione/shop.html";
            System.Diagnostics.Process.Start(path);
            textBox1.ReadOnly = false;
            textBox2.ReadOnly = false;
            textBox3.ReadOnly = false;
            button2.Enabled = true;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            try
            {
                if (int.Parse(textBox1.Text) > utileNetto)
                    MessageBox.Show("Impossibile effettuare l'acquisto");
                else
                {

                utileNetto = utileNetto - int.Parse(textBox1.Text);
                if (utileNetto < 0)
                    utileNetto = 0;
                label3.Text = "utile netto: " + utileNetto + "€";
                textBox1.ReadOnly = true;
                textBox2.ReadOnly = true;
                button3.Enabled = false;
                textBox3.ReadOnly = true;
                codici.Add(textBox2.Text);
                }
            }
            catch
            {
                MessageBox.Show("");
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            if (textBox3.Text == "IDR")
            {
                DialogResult dialogResult = MessageBox.Show("La manutenzione costa 6800€\nProcedere?", "", MessageBoxButtons.YesNo);
                if (dialogResult == DialogResult.Yes)
                {
                    utileNetto = utileNetto - 6800;
                    if (utileNetto < 0)
                        utileNetto = 0;
                    label3.Text = "utile netto: " + utileNetto + "€";
                }
                else if (dialogResult == DialogResult.No)
                {

                }
            }
            else if (codici.Contains(textBox3.Text))
                MessageBox.Show("Articolo coperto da garanzia");
            else
                MessageBox.Show("Codice articolo inserito erroneamente");        
        }

        private void GestioneCosti_Load(object sender, EventArgs e)
        {

        }
    }
}
