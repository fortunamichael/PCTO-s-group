﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp21
{
    public partial class Pala_eolica : Form
    {
        public Pala_eolica()
        {
            InitializeComponent();
        }

        private void Pala_eolica_Load(object sender, EventArgs e)
        {

        }

        public decimal Pt;
        public decimal V;
        public decimal A;
        public decimal R;

        private void button1_Click(object sender, EventArgs e)
        {
            V = numericUpDown1.Value;
            A = numericUpDown2.Value * numericUpDown2.Value * Convert.ToDecimal(Math.PI);
            R = numericUpDown3.Value;
            Pt = ((((V * V * V) / 2) * A * R) * numericUpDown4.Value) / 100;
            listView1.Items.Clear();
            listView1.Items.Add("Potenza generata: " + Pt + "W");
        }
    }
}
