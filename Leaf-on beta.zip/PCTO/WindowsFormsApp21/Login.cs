﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp21
{
    public partial class Login : Form
    {
        public Login()
        {
            InitializeComponent();
        }

        private void panel3_Paint(object sender, PaintEventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (textBox1.Text == "Ammin" && textBox2.Text == "Ammin")
            {
                Log.credenziali = new Log(textBox1.Text, textBox2.Text);
                Log.credenziali.Username = textBox1.Text;
                Log.credenziali.Password = textBox2.Text;
                Menu f = new Menu();
                Login lo = new Login();
                f.ShowDialog();
                lo.Hide();
            }
            else
                MessageBox.Show("Credenziali non valide!");
        }

        private void textBox1_DoubleClick(object sender, EventArgs e)
        {
            textBox1.Text = "";
        }

        private void textBox2_DoubleClick(object sender, EventArgs e)
        {
            textBox2.Text = "";
        }
    }
}
