﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp21
{
    public partial class Fabbisogno : Form
    {
        public Fabbisogno()
        {
            InitializeComponent();
        }
        int tot = 0;
        int totI = 0;
        int E = 60;
        int A = 50;
        int S = 480;
        int I = 81;
        int El = 600;
        int G = 50;
        List<string> energie = new List<string>();
        List<int> quantità = new List<int>();
        private void Fabbisogno_Load(object sender, EventArgs e)
        {

        }

        private void btEolica_Click_1(object sender, EventArgs e)
        {
            totale.Text = "Totale: 0";
            listView1.Items.Clear();
            var item1 = new ListViewItem(new[] { "Energia Eolica", "60€" });
            quantità.Add(E);
            energie.Add("Eolica€");
            foreach (var item in energie)
            {
                listView1.Items.Add(item);
            }          
            totI = E;
            tot = tot + E;
            totale.Text = "TOTALE: " + tot + "€";
        }

        private void btAltreE_Click_1(object sender, EventArgs e)
        {
            totale.Text = "Totale: 0";
            listView1.Items.Clear();
            var item1 = new ListViewItem(new[] { "Altre energie", "50€" });
            quantità.Add(A);
            energie.Add("Energie E.€");
            foreach (var item in energie)
            {
                listView1.Items.Add(item);
            }
            totI = A;
            tot = tot + A;
            totale.Text = "TOTALE: " + tot + "€";
        }

        private void btSolare_Click_1(object sender, EventArgs e)
        {
            totale.Text = "Totale: 0";
            listView1.Items.Clear();
            var item1 = new ListViewItem(new[] { "Energia Solare", "480€" });
            quantità.Add(S);
            energie.Add("Solare");
            foreach (var item in energie)
            {
                listView1.Items.Add(item);
            }
            totI = S;
            tot = tot + S;
            totale.Text = "TOTALE: " + tot + "€";
        }

        private void btIdroelettrica_Click_1(object sender, EventArgs e)
        {
            totale.Text = "Totale: 0";
            listView1.Items.Clear();
            var item1 = new ListViewItem(new[] { "Energia Idroelettrica", "81" });
            quantità.Add(I);
            energie.Add("Idroelettrica");
            foreach (var item in energie)
            {
                listView1.Items.Add(item);
            }
            totI = I;
            tot = tot + I;
            totale.Text = "TOTALE: " + tot + "€";
        }

        private void btElettrica_Click_1(object sender, EventArgs e)
        {
            totale.Text = "Totale: 0";
            listView1.Items.Clear();
            var item1 = new ListViewItem(new[] { "Energia Elettrica", "600€" });
            energie.Add("Elettrica");
            quantità.Add(E);
            foreach (var item in energie)
            {
                listView1.Items.Add(item);
            }
            totI = El;
            tot = tot + El;
            totale.Text = "TOTALE: " + tot + "€";
        }

        private void btGas_Click_1(object sender, EventArgs e)
        {

            totale.Text = "Totale: 0";
            listView1.Items.Clear();
            var item1 = new ListViewItem(new[] { "Energia Gas Naturale", "50€" });
            energie.Add("Gas Naturale");
            quantità.Add(G);
            foreach (var item in energie)
            {
                listView1.Items.Add(item);
            }
            totI = G;
            tot = tot + G;
            totale.Text = "TOTALE: " + tot + "€";
        }

        private void elimina_Click_1(object sender, EventArgs e)
        {
            listView1.Items.Clear();
            if (energie.Count == 0 && quantità.Count == 0)
                MessageBox.Show("Nessun valore messo");
            else
            {

            var x = energie.Last();
            var i = quantità.Last();
            energie.Remove(x);
            quantità.Remove(i);
            foreach (var item in energie)
            {
                listView1.Items.Add(item);
            }
            tot = tot - i;
            if (tot < 0)
                tot = 0;
            totale.Text = "TOTALE: " + tot + "€";
            }
        }
    }
}
