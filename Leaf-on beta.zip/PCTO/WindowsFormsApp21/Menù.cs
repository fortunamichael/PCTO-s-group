﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp21
{
    public partial class Menu : Form
    {
        public Menu()
        {
            InitializeComponent();
            panel3.Visible = false;
            ApriForm(new Home());
        }

        private void Hide()
        {
            if (panel3.Visible == true)
                panel3.Visible = false;
        }

        private void Show(Panel sub)
        {
            if (sub.Visible == false)
            {
                Hide();
                sub.Visible = true;
            }
            else
                sub.Visible = false;
        }
        private Form FormAperto = null;

        private void ApriForm(Form Form)
        {
            if (FormAperto != null)
                FormAperto.Close();
            FormAperto = Form;
            Form.TopLevel = false;
            Form.FormBorderStyle = FormBorderStyle.None;
            Form.Dock = DockStyle.Fill;
            mediabutton.Controls.Add(Form);
            mediabutton.Tag = Form;
            Form.BringToFront();
            Form.Show();
        }

        private void Menu_Load(object sender, EventArgs e)
        {

        }

        private void button2_Click_1(object sender, EventArgs e)
        {
            
        }

        private void button1_Click(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            ApriForm(new Fabbisogno());
        }

        private void button3_Click(object sender, EventArgs e)
        {
        }

        private void button4_Click(object sender, EventArgs e)
        {

        }

        private void button5_Click(object sender, EventArgs e)
        {

        }

        private void button6_Click(object sender, EventArgs e)
        {

        }

        private void button7_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void button14_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            Login lo = new Login();
            Menu me = new Menu();
            lo.Show();
            me.Close();
        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void panel2_Paint(object sender, PaintEventArgs e)
        {

        }

        private void button2_Click_2(object sender, EventArgs e)
        {
            ApriForm(new Fabbisogno());
        }

        private void button3_Click_1(object sender, EventArgs e)
        {
            ApriForm(new GestioneCosti());
        }

        private void button4_Click_1(object sender, EventArgs e)
        {
            
            
        }

        private void button5_Click_1(object sender, EventArgs e)
        {
            Login lo = new Login();
            Close();
        }

        private void button1_Click_2(object sender, EventArgs e)
        {

            ApriForm(new Home());
        }

        private void button6_Click_1(object sender, EventArgs e)
        {
            Application.Exit();
        }
        #region error
        private void pictureBox1_MouseHover(object sender, EventArgs e)
        {

        }

        private void pictureBox1_MouseEnter(object sender, EventArgs e)
        {

        }

        private void pictureBox1_MouseUp(object sender, MouseEventArgs e)
        {

        }

        private void button1_MouseEnter(object sender, EventArgs e)
        {

        }

        private void button1_MouseUp(object sender, MouseEventArgs e)
        {

        }
        #endregion

        private void button1_MouseHover(object sender, EventArgs e)
        {

        }

        private void button1_MouseLeave(object sender, EventArgs e)
        {

        }

        private void button12_MouseHover(object sender, EventArgs e)
        {

        }

        private void button12_MouseLeave(object sender, EventArgs e)
        {

        }

        private void button13_MouseHover(object sender, EventArgs e)
        {
            pictureBox5.BackColor = button7.BackColor;
        }

        private void button13_MouseLeave(object sender, EventArgs e)
        {

        }

        private void button4_MouseHover(object sender, EventArgs e)
        {
            pictureBox4.BackColor = button7.BackColor;
        }

        private void button4_MouseLeave(object sender, EventArgs e)
        {

        }

        private void button5_MouseHover(object sender, EventArgs e)
        {
            pictureBox5.BackColor = button7.BackColor;
        }

        private void button5_MouseLeave(object sender, EventArgs e)
        {

        }
        #region useless
        private void pictureBox4_Click(object sender, EventArgs e)
        {

        }

        private void button8_Click(object sender, EventArgs e)
        {

        }

        private void button9_Click(object sender, EventArgs e)
        {

        }

        private void button10_Click(object sender, EventArgs e)
        {

        }

        private void panel1_Paint_1(object sender, PaintEventArgs e)
        {

        }

        private void mediabutton_Paint(object sender, PaintEventArgs e)
        {

        }

        private void panel2_Paint_1(object sender, PaintEventArgs e)
        {

        }
        #endregion 
        private void button15_Click(object sender, EventArgs e)
        {
            Show(panel3);
        }

        private void button19_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void button16_Click(object sender, EventArgs e)
        {
            ApriForm(new Solare());
        }

        private void button17_Click(object sender, EventArgs e)
        {
            ApriForm(new Pala_eolica());
        }

        private void button18_Click(object sender, EventArgs e)
        {
            ApriForm(new Idroelettrica());
        }

        private void button14_Click_1(object sender, EventArgs e)
        {
            ApriForm(new GestioneCosti());
        }

        private void button13_Click(object sender, EventArgs e)
        {
            ApriForm(new Fabbisogno());
        }

        private void button12_Click(object sender, EventArgs e)
        {
            ApriForm(new Home());
        }

        private void button12_MouseHover_1(object sender, EventArgs e)
        {
            button12.BackColor = button7.BackColor;
            pictureBox7.BackColor = button7.BackColor;
        }

        private void button12_MouseLeave_1(object sender, EventArgs e)
        {
            button12.BackColor = panel3.BackColor;
            pictureBox7.BackColor = button12.BackColor;
        }

        private void button13_MouseHover_1(object sender, EventArgs e)
        {
            button13.BackColor = button7.BackColor;
            pictureBox5.BackColor = button7.BackColor;
        }

        private void button13_MouseLeave_1(object sender, EventArgs e)
        {
            button13.BackColor = panel3.BackColor;
            pictureBox5.BackColor = panel3.BackColor;
        }

        private void button14_MouseHover(object sender, EventArgs e)
        {
            button14.BackColor = button7.BackColor;
            pictureBox3.BackColor = button7.BackColor;
        }

        private void button14_MouseLeave(object sender, EventArgs e)
        {
            button14.BackColor = panel3.BackColor;
            pictureBox3.BackColor = panel3.BackColor;
        }

        private void button15_MouseHover(object sender, EventArgs e)
        {
            button15.BackColor = button7.BackColor;
            pictureBox4.BackColor = button7.BackColor;
        }

        private void button15_MouseLeave(object sender, EventArgs e)
        {
            button15.BackColor = panel3.BackColor;
            pictureBox4.BackColor = panel3.BackColor;
        }

        private void button16_MouseHover(object sender, EventArgs e)
        {
            button16.BackColor = button7.BackColor;
            pictureBox1.BackColor = button7.BackColor;
        }

        private void button16_MouseLeave(object sender, EventArgs e)
        {
            button16.BackColor = panel3.BackColor;
            pictureBox1.BackColor = panel3.BackColor;
        }

        private void button17_MouseHover(object sender, EventArgs e)
        {
            button17.BackColor = button7.BackColor;
            pictureBox2.BackColor = button7.BackColor;
        }

        private void button17_MouseLeave(object sender, EventArgs e)
        {
            button17.BackColor = panel3.BackColor;
            pictureBox2.BackColor = panel3.BackColor;
        }

        private void button18_MouseHover(object sender, EventArgs e)
        {
            button18.BackColor = button7.BackColor;
            pictureBox8.BackColor = button7.BackColor;
        }

        private void button18_MouseLeave(object sender, EventArgs e)
        {
            button18.BackColor = panel3.BackColor;
            pictureBox8.BackColor = panel3.BackColor;
        }

        private void button19_MouseHover(object sender, EventArgs e)
        {
            button19.BackColor = button7.BackColor;
            pictureBox9.BackColor = button7.BackColor;
        }

        private void button19_MouseLeave(object sender, EventArgs e)
        {
            button19.BackColor = panel3.BackColor;
            pictureBox9.BackColor = panel3.BackColor;
            pictureBox9.BackColor = panel3.BackColor;
        }

        private void button19_Click_1(object sender, EventArgs e)
        {
            ApriForm(new Energetico());
        }

        private void button1_Click_3(object sender, EventArgs e)
        {
            Close();
        }
    }
}

