﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp21
{
    public partial class Solare : Form
    {
        public Solare()
        {
            InitializeComponent();
        }

        private void Solare_Load(object sender, EventArgs e)
        {

        }
        decimal area;
        decimal ore;
        decimal potenza;

        private void button1_Click(object sender, EventArgs e)
        {
            listView1.Items.Clear();
            area = numericUpDown1.Value;
            ore = numericUpDown2.Value;
            if(comboBox1.Text == "Silicio monocristallino")
            {
                if (ore >= 11 && ore < 15)
                {
                    potenza = (area * 9);
                    //potenza = potenza * ore;
                    listView1.Items.Add("Potenza generata: " + potenza + "Kw");
                }
                else if (ore >= 6 || ore <= 10 || ore > 15 || ore <= 20)
                {
                    potenza = ((area * 9) * 60) / 100;
                   // potenza = potenza * ore;
                    listView1.Items.Add("Potenza generata: " + potenza + "Kw");
                }
                else
                    MessageBox.Show("I pannelli solare non riescono a produrre energia senza luce solare");
            }
            else if (comboBox1.Text == "Silicio policristallino")
            {
                 if (ore <= 11 && ore < 15)
                {
                    potenza = area * 11;
                   // potenza = potenza * ore;
                    listView1.Items.Add("Potenza generata: " + potenza + "Kw");
                }
                else if (ore >= 6 || ore <= 10 || ore > 15 || ore <= 20)
                {
                    potenza = ((area * 11) * 60) / 100;
                   // potenza = potenza * ore;
                    listView1.Items.Add("Potenza generata: " + potenza + "Kw");
                }
            }
            else
                MessageBox.Show("I pannelli solare non riescono a produrre energia senza luce solare");
        }
    }
}
